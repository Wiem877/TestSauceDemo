import http from 'k6/http';
import { check, sleep } from 'k6';
import { Rate } from 'k6/metrics';

export let errorRate = new Rate('errors');

export let options = {
    stages: [
        { duration: '2m', target: 20 },
        { duration: '3m', target: 50 },
        { duration: '2m', target: 20 }
    ],
    thresholds: {
        errors: ['rate<0.05'],
        http_req_duration: ['p(95)<2000']
    }
};

export default function () {
    // Login
    let loginRes = http.post('https://www.saucedemo.com/', { username: 'standard_user', password: 'secret_sauce' });
    let loginSuccess = check(loginRes, {
        'login success': (r) => r.status === 200 && r.body.includes('/inventory.html')
    });
    errorRate.add(!loginSuccess);
    sleep(1);

    // Go to products page
    let prodRes = http.get('https://www.saucedemo.com/inventory.html');
    check(prodRes, { 'products loaded': (r) => r.status === 200 });

    // Add product to cart
    let addCartRes = http.post('https://www.saucedemo.com/cart.html', { product_id: 1 });
    check(addCartRes, { 'added to cart': (r) => r.status === 200 });
    sleep(1);

    // Checkout step one
    let checkoutRes = http.get('https://www.saucedemo.com/checkout-step-one.html');
    check(checkoutRes, { 'checkout page loaded': (r) => r.status === 200 });
    sleep(1);
}
