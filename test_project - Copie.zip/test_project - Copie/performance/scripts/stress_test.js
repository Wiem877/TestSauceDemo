import http from 'k6/http';
import { check, sleep } from 'k6';
import { Rate } from 'k6/metrics';

export let errorRate = new Rate('errors');

export let options = {
    stages: [
        { duration: '1m', target: 200 },
        { duration: '2m', target: 200 },
        { duration: '1m', target: 10 }
    ],
    thresholds: {
        errors: ['rate<0.1'],
        http_req_duration: ['p(95)<3000']
    }
};

export default function () {
    let res = http.post('https://www.saucedemo.com/', {
        username: 'standard_user',
        password: 'secret_sauce'
    });

    let success = check(res, {
        'status 200': (r) => r.status === 200,
        'inventory page': (r) => r.body.includes('/inventory.html')
    });

    errorRate.add(!success);
    sleep(1);
}
