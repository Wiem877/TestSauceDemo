import http from 'k6/http';
import { check, sleep } from 'k6';
import { Rate } from 'k6/metrics';

export let errorRate = new Rate('errors');

export let options = {
    vus: 50,
    duration: '5m',
    thresholds: {
        errors: ['rate<0.05'],
        http_req_duration: ['p(95)<2000']
    }
};

export default function () {
    let res = http.post('https://www.saucedemo.com/', {
        username: 'standard_user',
        password: 'secret_sauce'
    });

    let loginSuccess = check(res, {
        'status is 200': (r) => r.status === 200,
        'redirected to inventory': (r) => r.body.includes('/inventory.html')
    });

    errorRate.add(!loginSuccess);
    sleep(1);
}
