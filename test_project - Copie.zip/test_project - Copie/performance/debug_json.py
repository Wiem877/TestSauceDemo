# performance/debug_json.py
import os
import json
import glob

def debug_json_files():
    """Affiche le contenu des fichiers JSON pour déboguer"""
    results_dir = os.path.join(os.path.dirname(__file__), "results")
    json_files = glob.glob(os.path.join(results_dir, "*.json"))
    
    print("🔍 DEBUG - Analyse des fichiers JSON")
    print("="*60)
    
    for json_file in json_files[:2]:  # Analyser seulement 2 fichiers
        filename = os.path.basename(json_file)
        print(f"\n📄 Fichier: {filename}")
        print("-"*40)
        
        try:
            with open(json_file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Afficher les 10 premières lignes
            lines = content.strip().split('\n')
            print(f"Nombre de lignes: {len(lines)}")
            
            # Analyser chaque ligne
            for i, line in enumerate(lines[:5]):  # 5 premières lignes
                print(f"\nLigne {i+1}:")
                if line.strip():
                    try:
                        data = json.loads(line)
                        # Chercher les métriques importantes
                        if 'metrics' in data:
                            metrics = data['metrics']
                            print("  📊 Métriques trouvées:")
                            
                            # Afficher les clés disponibles
                            for key in metrics.keys():
                                print(f"    - {key}")
                                
                            # Afficher http_req_duration si disponible
                            if 'http_req_duration' in metrics:
                                values = metrics['http_req_duration'].get('values', {})
                                print(f"    Temps de réponse: avg={values.get('avg', 'N/A')}ms")
                            
                            # Afficher les thresholds
                            if 'state' in data:
                                state = data['state']
                                print(f"    Statut thresholds: {state.get('thresholds', 'N/A')}")
                        
                    except json.JSONDecodeError:
                        print(f"  ❌ Ligne {i+1} n'est pas du JSON valide")
                        
        except Exception as e:
            print(f"❌ Erreur: {e}")

def check_login_load():
    """Vérifie spécifiquement le fichier login-load qui a échoué"""
    print("\n\n🔍 VÉRIFICATION SPÉCIFIQUE login-load")
    print("="*60)
    
    results_dir = os.path.join(os.path.dirname(__file__), "results")
    login_files = glob.glob(os.path.join(results_dir, "*login-load*.json"))
    
    for json_file in login_files:
        filename = os.path.basename(json_file)
        print(f"\n📄 {filename}:")
        
        with open(json_file, 'r', encoding='utf-8') as f:
            content = f.read()
        
        lines = content.strip().split('\n')
        
        # Chercher la ligne avec l'erreur
        for line in lines:
            if 'thresholds' in line.lower() and 'crossed' in line.lower():
                print(f"  ❌ ERREUR TROUVÉE: {line}")
            
            if 'http_req_duration' in line:
                try:
                    data = json.loads(line)
                    if 'metrics' in data and 'http_req_duration' in data['metrics']:
                        values = data['metrics']['http_req_duration']['values']
                        avg = values.get('avg', 0)
                        p95 = values.get('p95', 0)
                        print(f"  ⏱️  Temps de réponse: avg={avg}ms, p95={p95}ms")
                except:
                    pass

if __name__ == "__main__":
    debug_json_files()
    check_login_load()