# performance/k6_generator.py
import os
import json
import sys;
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
# Ajouter le dossier test_generation au PATH Python
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../test_generation')))

from gemini_test_generator import GeminiTestGenerator  # Votre classe existante

class K6ScriptGenerator:
    """Génère les scripts k6 en utilisant votre AI existante"""
    
    def __init__(self, api_key=None):
        self.generator = GeminiTestGenerator(api_key=api_key)
        self.scripts_dir = "performance/scripts"
        os.makedirs(self.scripts_dir, exist_ok=True)
    
    def generate_login_script(self):
        """Génère le script k6 pour le login"""
        prompt = """
        Génère un script k6 pour tester la performance du login sur https://www.saucedemo.com/
        
        Requirements:
        
        - 10-100 virtual users
        - 5 minutes duration  
        - Measure response time < 2s
        - Success rate > 95%
        - Check redirect to inventory page
        - Use standard_user / secret_sauce
        - Include thresholds and basic reporting
        
        Return only the k6 JavaScript code.
        """
        
        script = self.generator.generate_test_code(prompt, "k6")
        self._save_script("login_load.js", script)
        return script
    
    def generate_full_flow_script(self):
        """Génère le script k6 pour le flux complet"""
        prompt = """
        Génère un script k6 complet pour SauceDemo simulant le parcours utilisateur:
        1. Login (standard_user / secret_sauce)
        2. Page produits (/inventory.html)
        3. Ajouter un produit au panier
        4. Page panier (/cart.html)
        5. Début checkout (/checkout-step-one.html)
        
        Configuration:
        - Stages: 20 users → 50 users → 20 users
        - Total duration: 7 minutes
        - Thresholds for each step
        - Basic checks and error handling
        - Performance metrics per step
        
        Return only the k6 JavaScript code.
        """
        
        script = self.generator.generate_test_code(prompt, "k6")
        self._save_script("full_flow.js", script)
        return script
    
    def generate_stress_script(self):
        """Génère le script k6 pour stress test"""
        prompt = """
        Génère un script k6 de stress test pour SauceDemo.
        
        Stress scenario:
        - Rapid spike: 10 → 200 users in 1 minute
        - Maintain peak: 2 minutes at 200 users  
        - Ramp down: 200 → 10 users in 1 minute
        - Total: 5 minutes
        
        Focus on:
        - Error rates under stress
        - Response time degradation
        - System recovery
        - Breaking point identification
        
        Return only the k6 JavaScript code.
        """
        
        script = self.generator.generate_test_code(prompt, "k6")
        self._save_script("stress_test.js", script)
        return script
    
    def _save_script(self, filename, code):
        """Sauvegarde le script généré"""
        filepath = os.path.join(self.scripts_dir, filename)
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(code)
        print(f"✅ Script généré: {filepath}")
    
    def generate_all_scripts(self):
        """Génère tous les scripts k6"""
        print("🚀 Génération des scripts k6 avec AI...")
        
        scripts = {
            "login_load.js": self.generate_login_script(),
            "full_flow.js": self.generate_full_flow_script(), 
            "stress_test.js": self.generate_stress_script()
        }
        
        print("✅ Tous les scripts k6 ont été générés!")
        return scripts
if __name__ == "__main__":
        
        print("🚀 Génération de tous les scripts k6 via AI...")
        generator = K6ScriptGenerator()
        generator.generate_all_scripts()
        print("✅ Tous les scripts k6 ont été générés dans performance/scripts/")
