import os
import json
from datetime import datetime
import glob
import webbrowser

def load_k6_results(json_file):
    """Charge les résultats k6 depuis un fichier JSON et formate pour le dashboard"""
    with open(json_file, 'r', encoding='utf-8') as f:
        data = json.load(f)

    # Extraire les métriques principales
    metrics = data.get('metrics', {})
    tests = []

    # Créer un test pour chaque scénario principal
    for name, info in data.get('scenarios', {}).items():
        checks = info.get('checks', {})
        http_req_duration = info.get('http_req_duration', {})
        http_reqs = info.get('http_reqs', {})

        tests.append({
            'name': name,
            'status': 'PASS' if checks.get('rate', 1) >= 0.95 else 'FAIL',
            'http_req_duration_avg': http_req_duration.get('avg', 0),
            'http_req_duration_p95': http_req_duration.get('p(95)', 0),
            'http_reqs_count': http_reqs.get('count', 0),
            'vus_max': info.get('vus_max', 1),
            'checks_rate': checks.get('rate', 1),
            'error': None if checks.get('rate', 1) >= 0.95 else 'Threshold dépassé',
            'timestamp': datetime.now()
        })
    return tests

def create_final_report():
    """Crée un dashboard HTML à partir des résultats JSON k6"""
    json_dir = os.path.join(os.path.dirname(__file__), "reports")
    os.makedirs(json_dir, exist_ok=True)

    # Récupérer tous les fichiers JSON k6
    json_files = glob.glob(os.path.join(json_dir, "*.json"))
    all_tests = []

    for file in json_files:
        all_tests.extend(load_k6_results(file))

    if not all_tests:
        print("❌ Aucun fichier JSON k6 trouvé dans 'reports/'")
        return

    # Calcul des stats globales
    total_tests = len(all_tests)
    passed_tests = sum(1 for t in all_tests if t['status'] == 'PASS')
    failed_tests = total_tests - passed_tests

    tests_with_requests = [t for t in all_tests if t['http_reqs_count'] > 0]
    if tests_with_requests:
        avg_response_time = sum(t['http_req_duration_avg'] for t in tests_with_requests) / len(tests_with_requests)
        total_requests = sum(t['http_reqs_count'] for t in tests_with_requests)
        max_vus = max(t['vus_max'] for t in tests_with_requests)
    else:
        avg_response_time = 0
        total_requests = 0
        max_vus = 1

    # Génération HTML (simplifiée, reprend le style que tu avais)
    html_dir = os.path.join(os.path.dirname(__file__), "reports")
    os.makedirs(html_dir, exist_ok=True)
    report_file = os.path.join(html_dir, f"dashboard_final_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html")

    html_content = f"""
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>📊 Dashboard Performance K6</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
body {{ font-family: Arial, sans-serif; background: #f0f2f5; padding: 20px; }}
h1 {{ text-align: center; }}
.stats {{ display: flex; justify-content: space-around; margin-bottom: 30px; }}
.stat {{ background: white; padding: 20px; border-radius: 12px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); text-align:center; }}
table {{ width: 100%; border-collapse: collapse; background: white; border-radius: 12px; overflow: hidden; }}
th, td {{ padding: 12px; border-bottom: 1px solid #ddd; text-align: center; }}
.status-pass {{ color: green; font-weight: bold; }}
.status-fail {{ color: red; font-weight: bold; }}
</style>
</head>
<body>
<h1>📊 Dashboard Performance K6</h1>

<div class="stats">
    <div class="stat">Tests Réussis<br><strong>{passed_tests}/{total_tests}</strong></div>
    <div class="stat">Temps Moyen<br><strong>{avg_response_time:.0f} ms</strong></div>
    <div class="stat">Requêtes<br><strong>{total_requests}</strong></div>
    <div class="stat">VUs Max<br><strong>{max_vus}</strong></div>
</div>

<h2>Résultats Détaillés</h2>
<table>
    <thead>
        <tr>
            <th>Test</th><th>Statut</th><th>Temps Moyen (ms)</th><th>P95 (ms)</th>
            <th>Requêtes</th><th>VUs Max</th><th>Taux Succès</th>
        </tr>
    </thead>
    <tbody>
"""
    for t in all_tests:
        status_class = "status-pass" if t['status'] == 'PASS' else "status-fail"
        html_content += f"""
        <tr>
            <td>{t['name']}</td>
            <td class="{status_class}">{t['status']}</td>
            <td>{t['http_req_duration_avg']:.0f}</td>
            <td>{t['http_req_duration_p95']:.0f}</td>
            <td>{t['http_reqs_count']}</td>
            <td>{t['vus_max']}</td>
            <td>{t['checks_rate']*100:.1f}%</td>
        </tr>
"""

    html_content += """
    </tbody>
</table>

<h2>Graphiques</h2>
<canvas id="responseChart" height="100"></canvas>
<canvas id="statusChart" height="100"></canvas>

<script>
const names = """ + json.dumps([t['name'] for t in all_tests]) + """;
const responseTimes = """ + json.dumps([t['http_req_duration_avg'] for t in all_tests]) + """;
const statuses = """ + json.dumps([t['status'] for t in all_tests]) + """;

new Chart(document.getElementById('responseChart').getContext('2d'), {
    type: 'bar',
    data: { labels: names, datasets: [{ label: 'Temps moyen (ms)', data: responseTimes, backgroundColor: '#4cc9f0' }] },
    options: { responsive: true, plugins: { legend: { display: false } } }
});

const passCount = statuses.filter(s => s==='PASS').length;
const failCount = statuses.filter(s => s==='FAIL').length;

new Chart(document.getElementById('statusChart').getContext('2d'), {
    type: 'doughnut',
    data: { labels: ['PASS','FAIL'], datasets: [{ data: [passCount, failCount], backgroundColor: ['#4cc9f0','#f72585'] }] },
    options: { responsive: true }
});
</script>

</body>
</html>
"""

    with open(report_file, 'w', encoding='utf-8') as f:
        f.write(html_content)

    print(f"✅ Dashboard généré : {report_file}")
    webbrowser.open(f"file:///{report_file.replace(os.sep, '/')}")


if __name__ == "__main__":
    print("🚀 Génération du Dashboard Performance K6 à partir des fichiers JSON...")
    create_final_report()