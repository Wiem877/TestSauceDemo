// performance/scripts/config.js
// Configuration partagée pour tous les scripts k6

export const sharedOptions = {
  discardResponseBodies: true,
  httpDebug: false,
  noConnectionReuse: false,
};

export const thresholds = {
  http_req_duration: ['p(95)<3000'],
  http_req_failed: ['rate<0.05'],
};

export const smokeTest = {
  vus: 5,
  duration: '2m',
};

export const loadTest = {
  stages: [
    { duration: '2m', target: 20 },
    { duration: '5m', target: 50 },
    { duration: '2m', target: 20 },
  ],
};

export const stressTest = {
  stages: [
    { duration: '1m', target: 10 },
    { duration: '2m', target: 100 },
    { duration: '1m', target: 10 },
  ],
};