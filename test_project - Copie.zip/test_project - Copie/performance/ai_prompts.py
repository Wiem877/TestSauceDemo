# performance/ai_prompts.py
"""
Prompts pour générer les scripts k6 avec Gemini
"""

K6_LOGIN_PROMPT = """
Génère un script k6 pour tester la performance du login sur SauceDemo.
Le script doit:

1. Tester avec 10 à 50 utilisateurs virtuels
2. Durée totale: 5 minutes
3. Mesurer le temps de réponse et le taux de succès
4. Inclure des thresholds pour détecter les problèmes
5. Utiliser les credentials: standard_user / secret_sauce
6. Vérifier que la redirection vers /inventory.html fonctionne
7. Générer un rapport simple

Retourne uniquement le code JavaScript pour k6.
"""

K6_FULL_FLOW_PROMPT = """
Génère un script k6 complet pour SauceDemo simulant le flux:
Login → Voir produits → Ajouter au panier → Checkout

Points importants:
- 5-30 utilisateurs virtuels
- Durée: 5-10 minutes  
- Stages progressifs
- Thresholds pour chaque étape
- Vérifications de base
- Rapport de performance

Retourne uniquement le code JavaScript.
"""

K6_STRESS_PROMPT = """
Génère un script k6 de stress test pour SauceDemo.
Test de pic de charge: 10 → 100 → 10 utilisateurs.
Durée totale: 5 minutes.
Focus sur la détection des points de rupture.
"""