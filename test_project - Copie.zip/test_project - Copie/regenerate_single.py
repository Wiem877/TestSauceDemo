# regenerate_single.py
import os
import time
from test_generation.gemini_test_generator import GeminiTestGenerator

def regenerate_cart_test():
    print("🔄 Régénération du test panier...")
    
    # Attendre pour éviter l'erreur 429
    time.sleep(10)
    
    generator = GeminiTestGenerator()
    
    # Charger la user story du panier
    user_story_path = "test_generation/input/user_story_cart.yaml"
    template_path = "test_generation/templates/pytest_template.j2"  # ← CORRECTION: .j2
    
    user_story = generator.load_user_story(user_story_path)
    if user_story:
        print(f"🔧 Génération du test pour: {user_story['user_story']['title']}")
        
        # Vérifier que le template existe
        if not os.path.exists(template_path):
            print(f"❌ Template non trouvé: {template_path}")
            return
        
        print("✅ Template chargé")
        
        # Générer le test
        generated_test = generator.generate_test_from_story(user_story, template_path)
        
        if generated_test:
            # Sauvegarder
            output_path = os.path.join("tests", "test_us_cart_01.py")
            with open(output_path, "w", encoding="utf-8") as f:
                f.write(generated_test)
            print(f"💾 Test sauvegardé: {output_path}")
            
            # Vérifier la syntaxe
            try:
                with open(output_path, "r") as f:
                    compile(f.read(), "test_us_cart_01.py", 'exec')
                print("✅ Syntaxe Python VALIDE")
            except SyntaxError as e:
                print(f"❌ Erreur de syntaxe: {e}")
        else:
            print("❌ Échec de la génération")

if __name__ == "__main__":
    regenerate_cart_test()