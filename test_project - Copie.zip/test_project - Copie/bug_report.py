import os
import json
import webbrowser
from datetime import datetime

# --------------------------
# CONFIGURATION
# --------------------------
RESULT_FOLDER = os.path.join(os.getcwd(), "results")
SCREENSHOTS_DIR = os.path.join(os.getcwd(), "screenshots")  # si tu as des screenshots

# Chercher tous les fichiers JSON générés par pytest
json_files = [os.path.join(RESULT_FOLDER, f) for f in os.listdir(RESULT_FOLDER) if f.endswith(".json")]

# --------------------------
# COLLECTE DES DONNÉES
# --------------------------
results = []

for jf in json_files:
    with open(jf, "r", encoding="utf-8") as f:
        data = json.load(f)
        browser_name = os.path.basename(jf).split("_")[1].replace(".json","").upper()
        tests_details = []
        passed = failed = skipped = 0
        total_time = 0
        for t in data.get("tests", []):
            outcome = t.get("outcome")
            if outcome == "passed":
                passed += 1
            elif outcome == "failed":
                failed += 1
            elif outcome == "skipped":
                skipped += 1
            duration = t.get("duration", 0)
            total_time += duration
            tests_details.append({
                "name": t.get("nodeid"),
                "status": outcome,
                "message": t.get("longrepr", ""),
                "duration": duration
            })

        results.append({
            "browser": browser_name,
            "total": passed + failed + skipped,
            "passed": passed,
            "failed": failed,
            "skipped": skipped,
            "execution_time": total_time,
            "html_file": jf.replace(".json", ".html"),
            "tests": tests_details
        })

# --------------------------
# GÉNÉRATION HTML
# --------------------------
timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
report_path = os.path.join(RESULT_FOLDER, f"Rapport_Complet_{timestamp}.html")

browser_rows = ""
for r in results:
    status = "✅ PASS" if r["failed"] == 0 else "❌ FAIL"
    status_class = "success" if r["failed"] == 0 else "danger"
    
    # Détails des tests individuels
    test_rows = ""
    for t in r["tests"]:
        test_status_class = "text-success" if t["status"]=="passed" else ("text-danger" if t["status"]=="failed" else "text-warning")
        test_rows += f"""
        <tr>
            <td>{t['name']}</td>
            <td class="{test_status_class}">{t['status'].upper()}</td>
            <td>{t['duration']:.2f}s</td>
            <td>{t['message']}</td>
        </tr>
        """

    browser_rows += f"""
    <tr class="table-primary">
        <td colspan="4"><b>{r['browser']} - {status} - Total: {r['total']} Passés: {r['passed']} Échoués: {r['failed']} Ignorés: {r['skipped']} Temps: {r['execution_time']:.2f}s</b> 
        - <a href="{r['html_file']}" target="_blank">Rapport HTML</a></td>
    </tr>
    {test_rows}
    """

html = f"""
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Rapport Complet Selenium</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body {{ font-family: 'Segoe UI', sans-serif; background: #f5f7fa; }}
.header {{ background: #3498db; color: white; padding: 2rem; border-radius: 0 0 20px 20px; text-align:center; }}
.table-container {{ margin: 2rem auto; background:white; padding:1rem; border-radius:10px; box-shadow:0 5px 15px rgba(0,0,0,0.1); }}
</style>
</head>
<body>
<div class="header">
<h1>Rapport Complet Selenium</h1>
<p>Date: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}</p>
</div>
<div class="container table-container">
<h4>Détail par navigateur et tests</h4>
<table class="table table-bordered table-hover">
<thead>
<tr>
<th>Nom du test</th>
<th>Status</th>
<th>Durée</th>
<th>Message</th>
</tr>
</thead>
<tbody>
{browser_rows}
</tbody>
</table>
</div>
</body>
</html>
"""

with open(report_path, "w", encoding="utf-8") as f:
    f.write(html)

print(f"✅ Rapport complet généré : {report_path}")
webbrowser.open(f"file:///{report_path}")
