"""
Générateur de tests automatiques utilisant Google Gemini AI - VERSION CORRIGÉE
"""
import os
import re
import yaml
import sys;
from jinja2 import Template
from pathlib import Path
import google.generativeai as genai
# Ajoute le répertoire parent au chemin Python
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from test_generation.page_object_analyzer import PageObjectAnalyzer

class GeminiTestGenerator:
    def __init__(self, api_key=None, model="gemini-2.0-flash"):
        self.api_key = self._load_api_key()
        if not self.api_key:
            raise ValueError("❌ Clé API Gemini non trouvée dans api_key.txt")
            
        try:
            genai.configure(api_key=self.api_key)
            self.model = genai.GenerativeModel(model)
            self.analyzer = PageObjectAnalyzer()
            print(f"🤖 Générateur de tests Gemini initialisé avec le modèle: {model}")
        except Exception as e:
            print(f"❌ Erreur lors de l'initialisation de Gemini: {e}")
            raise
    
    def _load_api_key(self):
        try:
            with open("api_key.txt", "r") as f:
                key = f.read().strip()
                if key and key.startswith("AIza"):
                    print(f"✅ Clé API chargée: {key[:10]}...")
                    return key
                else:
                    print("❌ Clé invalide dans api_key.txt")
                    return None
        except FileNotFoundError:
            print("❌ Fichier api_key.txt non trouvé")
            return None

    def load_user_story(self, yaml_file_path):
        try:
            with open(yaml_file_path, 'r', encoding='utf-8') as file:
                data = yaml.safe_load(file)
            print(f"✅ User Story chargée: {data['user_story']['title']}")
            return data
        except FileNotFoundError:
            print(f"❌ Fichier YAML non trouvé: {yaml_file_path}")
            return None
        except Exception as e:
            print(f"❌ Erreur lors du chargement du YAML: {e}")
            return None

    def generate_test_from_story(self, user_story, template_path):
        try:
            print(f"🔧 Génération du test pour: {user_story['user_story']['title']}")
            
            with open(template_path, 'r', encoding='utf-8') as f:
                template_content = f.read()
            print("✅ Template chargé")
            
            methods_summary = self.analyzer.generate_methods_summary()
            print("✅ Page Objects analysés")
            
            prompt = self._build_test_generation_prompt(user_story, methods_summary, template_content)
            
            print("🤖 Appel à l'API Gemini...")
            response = self.model.generate_content(prompt)
            
            generated_code = self._clean_generated_code(response.text)
            
            print(f"✅ Test généré avec succès!")
            return generated_code
            
        except Exception as e:
            print(f"❌ Erreur lors de la génération: {e}")
            return None

    def _build_test_generation_prompt(self, user_story, methods_summary, template_content):
     yaml_content = yaml.dump(user_story, allow_unicode=True, default_flow_style=False)

     prompt_text = f"""
GÉNÈRE UN TEST PYTHON PARFAIT ET EXÉCUTABLE.

RÈGLES ABSOLUES :
1. UNIQUEMENT du code Python valide
2. COMMENCE par les imports exacts
3. FINIT à la dernière ligne de code
4. PAS de texte explicatif
5. PAS de commentaires hors code
6. PAS de ```python ou ```
7. UTILISE UNIQUEMENT les fixtures disponibles : driver, logged_in_driver

IMPORTS OBLIGATOIRES (copier exactement) :
from pages.base_page import BasePage
from pages.login_page import LoginPage
from pages.products_page import ProductsPage
from pages.cart_page import CartPage
from pages.checkout_page import CheckoutPage
from selenium.webdriver.common.by import By
import pytest

STRUCTURE OBLIGATOIRE :
- Une seule fonction de test par fichier
- Nom de fonction : test_us_[feature]_01
- Utiliser driver OU logged_in_driver selon le besoin
- Pas de classes, seulement des fonctions simples

FIXTURES DISPONIBLES :
- driver : navigateur non connecté
- logged_in_driver : navigateur déjà connecté

METHODES AUTORISÉES :
{methods_summary}

USER STORY :
{yaml_content}

GÉNÈRE LE CODE MAINTENANT :
{template_content}

CODE PYTHON SEULEMENT. RIEN D'AUTRE.
"""
     return prompt_text
  

    def _clean_generated_code(self, code):
     

     """
    Nettoyage agressif - ne garde que le code Python valide
    """
    # Supprimer tous les blocs markdown
     if "```python" in code:
          code = code.split("```python")[1].split("```")[0].strip()
     elif "```" in code:
         code = code.split("```")[1].split("```")[0].strip()
    
    # Supprimer les lignes non-Python
     lines = code.split('\n')
     cleaned_lines = []
    
     python_keywords = ['import ', 'from ', 'def ', 'class ', 'assert ', 'print(', 'if ', 'for ', 'while ', 'return ']
    
     for line in lines:
        stripped = line.strip()
        # Garder uniquement les lignes qui ressemblent à du Python
        if any(stripped.startswith(keyword) for keyword in python_keywords) or stripped == '' or stripped.startswith('@') or stripped.endswith(':') or ' = ' in line:
            cleaned_lines.append(line)
    
     cleaned_code = '\n'.join(cleaned_lines).strip()
    
    # Vérifier que ça commence par les imports
     if not cleaned_code.startswith('from ') and not cleaned_code.startswith('import '):
        # Trouver la première ligne valide
        for i, line in enumerate(cleaned_code.split('\n')):
            if line.strip().startswith(('from ', 'import ')):
                cleaned_code = '\n'.join(cleaned_code.split('\n')[i:])
                break
    
     return cleaned_code
    
    def generate_test_code(self, prompt, language="python"):
        """Appel direct à Gemini pour générer du code, pour compatibilité avec k6_generator.py"""
        try:
            response = self.model.generate_content(prompt)
            code = self._clean_generated_code(response.text)
            return code
        except Exception as e:
            print(f"❌ Erreur lors de generate_test_code: {e}")
            return ""
        