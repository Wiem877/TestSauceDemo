# Importation des modules nécessaires
import ast  # Module pour analyser la syntaxe Python (Abstract Syntax Tree)
import os   # Module pour interagir avec le système de fichiers
from pathlib import Path  # Module moderne pour manipuler les chemins de fichiers

class PageObjectAnalyzer:
    def __init__(self, pages_dir="pages"):
        # Initialise le chemin vers le dossier des Page Objects
        # Path() convertit le chemin en objet Path (plus facile à manipuler)
        self.pages_dir = Path(pages_dir)
        
    def analyze_page_objects(self):
        """Analyse les Page Objects pour découvrir les méthodes disponibles"""
        # Dictionnaire qui stockera les méthodes par classe
        methods_by_page = {}
        
        # Message de début d'analyse
        print("🔍 Analyse des Page Objects existants...")
        
        # Parcourt tous les fichiers .py dans le dossier pa+ges/
        # glob("*.py") trouve tous les fichiers avec extension .py
        for file_path in self.pages_dir.glob("*.py"):
            # Ignore les fichiers __init__.py et autres fichiers spéciaux
            if file_path.name.startswith('__'):
                continue
                
            # Affiche le fichier en cours d'analyse
            print(f"  📄 Analyse de {file_path.name}...")
            
            try:
                # Ouvre le fichier en mode lecture avec encodage UTF-8
                with open(file_path, 'r', encoding='utf-8') as f:
                    # Lit tout le contenu du fichier
                    content = f.read()
                
                # Parse le contenu Python en arbre syntaxique (AST)
                # ast.parse() transforme le code en structure arborescente
                tree = ast.parse(content)
                
                # Parcourt tous les nœuds de l'arbre syntaxique
                for node in ast.walk(tree):
                    # Vérifie si le nœud est une définition de classe
                    if isinstance(node, ast.ClassDef):
                        # Récupère le nom de la classe (ex: "LoginPage")
                        class_name = node.name
                        # Liste pour stocker les méthodes de cette classe
                        methods = []
                        
                        # Parcourt tous les éléments dans le corps de la classe
                        for item in node.body:
                            # Vérifie si l'élément est une définition de fonction
                            if isinstance(item, ast.FunctionDef):
                                # Ignore les méthodes privées (commençant par _)
                                if not item.name.startswith('_'):
                                    # Récupère les arguments de la fonction
                                    # item.args.args contient la liste des paramètres
                                    # arg.arg != 'self' exclut le paramètre 'self'
                                    args = [arg.arg for arg in item.args.args if arg.arg != 'self']
                                    
                                    # Récupère le docstring (commentaire de la fonction)
                                    docstring = ""
                                    # Vérifie si le corps de la fonction a au moins un élément
                                    if item.body and isinstance(item.body[0], ast.Expr):
                                        # Vérifie si le premier élément est une expression constante (docstring)
                                        if isinstance(item.body[0].value, ast.Constant):
                                            # Récupère la valeur du docstring
                                            docstring = item.body[0].value.value
                                    
                                    # Ajoute la méthode à la liste avec ses informations
                                    methods.append({
                                        'name': item.name,      # Nom de la méthode
                                        'args': args,           # Liste des arguments
                                        'docstring': docstring  # Docstring de la méthode
                                    })
                        
                        # Si on a trouvé des méthodes dans cette classe
                        if methods:
                            # Stocke les informations dans le dictionnaire
                            methods_by_page[class_name] = {
                                'file': file_path.name,  # Nom du fichier
                                'methods': methods       # Liste des méthodes
                            }
                            # Affiche un résumé de ce qu'on a trouvé
                            print(f"    ✅ Classe {class_name}: {[m['name'] for m in methods]}")
                            
            except Exception as e:
                # Gère les erreurs d'analyse (fichier corrompu, syntaxe invalide, etc.)
                print(f"    ❌ Erreur dans l'analyse de {file_path.name}: {e}")
        
        # Retourne le dictionnaire complet avec toutes les méthodes trouvées
        return methods_by_page

    def generate_methods_summary(self):
        """Génère un résumé des méthodes disponibles pour les prompts IA"""
        # Appelle la méthode d'analyse pour obtenir les données
        methods_info = self.analyze_page_objects()
        
        # Vérifie si des méthodes ont été trouvées
        if not methods_info:
            print("❌ Aucune méthode trouvée. Vérifiez que vos Page Objects existent dans le dossier 'pages/'")
            return "**AUCUNE MÉTHODE TROUVÉE** - Vérifiez vos Page Objects"
        
        # Commence à construire le résumé textuel
        summary = "**MÉTHODES DISPONIBLES DANS LES PAGE OBJECTS:**\n\n"
        
        # Parcourt chaque classe trouvée
        for class_name, info in methods_info.items():
            # Ajoute le nom de la classe et son fichier
            summary += f"**{class_name}** (fichier: {info['file']})\n"
            
            # Parcourt chaque méthode de la classe
            for method in info['methods']:
                # Convertit la liste d'arguments en string
                args_str = ", ".join(method['args'])
                # Ajoute la méthode avec sa signature
                summary += f"- `{method['name']}({args_str})`"
                
                # Ajoute le docstring s'il existe
                if method['docstring']:
                    # Nettoie le docstring (enlève les retours à la ligne)
                    clean_doc = method['docstring'].replace('\n', ' ').strip()
                    summary += f" - {clean_doc}"
                
                # Passe à la ligne suivante
                summary += "\n"
            
            # Ligne vide entre les classes pour la lisibilité
            summary += "\n"
        
        # Retourne le résumé complet
        return summary

# Code exécuté seulement si le fichier est lancé directement
if __name__ == "__main__":
    # Crée une instance de l'analyseur
    analyzer = PageObjectAnalyzer()
    
    # Génère le résumé des méthodes
    summary = analyzer.generate_methods_summary()
    
    # Affiche un séparateur visuel
    print("=" * 60)
    print("RÉSUMÉ COMPLET DES MÉTHODES DISPONIBLES:")
    print("=" * 60)
    
    # Affiche le résumé
    print(summary)
    
    # Sauvegarde le résumé dans un fichier texte pour référence future
    with open("page_objects_summary.txt", "w", encoding="utf-8") as f:
        f.write(summary)
    
    # Message de confirmation
    print("💾 Résumé sauvegardé dans: page_objects_summary.txt")