import requests
import json

def test_gemini():
    print("🔗 TEST GEMINI")
    print("=" * 30)
    
    # ⬇️ COLLEZ VOTRE NOUVELLE CLÉ ICI ⬇️
    API_KEY = "AIzaSyBjDGA6qpKSdW6Ydev2lSjHFwx-arBng4U"  # ← VOTRE NOUVELLE CLÉ PRIVÉE
    
    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-lite:generateContent?key={API_KEY}"
    
    data = {
        "contents": [{
            "parts": [{"text": "Dis bonjour"}]
        }]
    }
    
    try:
        response = requests.post(url, json=data, timeout=10)
        
        if response.status_code == 200:
            result = response.json()
            text = result['candidates'][0]['content']['parts'][0]['text']
            print("🎉 SUCCÈS !")
            print(f"🤖: {text}")
        else:
            print(f"❌ Erreur: {response.text}")
            
    except Exception as e:
        print(f"❌ Erreur: {e}")

test_gemini()