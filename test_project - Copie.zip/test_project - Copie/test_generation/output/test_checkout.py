import pytest
from selenium import webdriver
from pages.login_page import LoginPage
from pages.products_page import ProductsPage
from pages.cart_page import CartPage
from pages.checkout_page import CheckoutPage

@pytest.fixture
def driver():
    driver = webdriver.Chrome()
    driver.maximize_window()  # parfois nécessaire pour que les éléments soient visibles
    driver.get("https://www.saucedemo.com/")
    LoginPage(driver).standard_login()
    yield driver
    driver.quit()

def test_checkout_complete_process(driver):
    """Test processus checkout complet"""
    products = ProductsPage(driver)
    products.add_product_to_cart(0)
    products.go_to_cart()

    cart = CartPage(driver)
    cart.proceed_to_checkout()

    checkout = CheckoutPage(driver)
    checkout.fill_checkout_info("John", "Doe", "5000")
    checkout.continue_to_overview()
    checkout.finish_checkout()

    assert checkout.is_checkout_complete(), "Checkout non terminé"

def test_checkout_empty_fields_error(driver):
    """Test erreur champs vides"""
    products = ProductsPage(driver)
    products.add_product_to_cart(0)
    products.go_to_cart()

    cart = CartPage(driver)
    cart.proceed_to_checkout()

    checkout = CheckoutPage(driver)
    checkout.fill_checkout_info("", "", "")
    checkout.click_continue_for_error()
    
    error_message = checkout.get_error_message()
    assert error_message != "", f"Message d'erreur manquant, trouvé : '{error_message}'"
