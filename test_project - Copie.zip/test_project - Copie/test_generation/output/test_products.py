import pytest
from selenium import webdriver
from pages.login_page import LoginPage
from pages.products_page import ProductsPage

@pytest.fixture
def driver():
    driver = webdriver.Chrome()
    driver.get("https://www.saucedemo.com/")
    LoginPage(driver).standard_login()
    yield driver
    driver.quit()

def test_products_page_displayed(driver):
    """Test affichage page produits"""
    products = ProductsPage(driver)
    assert products.is_products_page_displayed(), "La page produits n'est pas affichée"

def test_product_count(driver):
    """Test nombre de produits"""
    products = ProductsPage(driver)
    assert products.get_product_count() > 0, "Aucun produit affiché"

def test_add_first_product_to_cart(driver):
    """Test ajout premier produit"""
    products = ProductsPage(driver)
    assert products.add_product_to_cart(0), "Ajout du premier produit échoué"
    assert products.get_cart_badge_count() != "0", "Badge panier non mis à jour"

def test_add_product_by_name(driver):
    """Test ajout par nom"""
    products = ProductsPage(driver)
    assert products.add_product_to_cart("Sauce Labs Backpack"), "Ajout par nom échoué"

def test_go_to_cart_from_products(driver):
    """Test navigation panier"""
    products = ProductsPage(driver)
    products.add_product_to_cart(0)
    assert products.go_to_cart(), "Navigation vers panier échouée"

def test_add_product_out_of_bounds(driver):
    """Test limite : ajout d’un produit avec index hors limites"""
    products = ProductsPage(driver)
    
    product_count = products.get_product_count()
    invalid_index = product_count  # index hors limite
    #index valide maximum → product_count - 1
    result = products.add_product_to_cart(invalid_index)
    
    # Le résultat doit indiquer que l'action a échoué
    assert result is False, "Un produit hors limites ne devrait pas pouvoir être ajouté"
    assert products.get_cart_badge_count() in ["", "0"], "Le panier ne doit pas être modifié"

