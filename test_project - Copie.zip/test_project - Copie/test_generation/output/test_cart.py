








import pytest
from selenium import webdriver
from pages.login_page import LoginPage
from pages.products_page import ProductsPage
from pages.cart_page import CartPage

@pytest.fixture
def driver():
    driver = webdriver.Chrome()
    driver.get("https://www.saucedemo.com/")
    LoginPage(driver).standard_login()
    yield driver
    driver.quit()

def test_cart_with_items(driver):
    """Test panier avec articles"""
    products = ProductsPage(driver)
    products.add_product_to_cart(0)
    products.go_to_cart()
    
    cart = CartPage(driver)
    assert cart.is_cart_page_displayed(), "La page panier n'est pas affichée"
    assert cart.get_cart_items_count() == 1, "Le panier doit contenir 1 article"

def test_remove_item_from_cart(driver):
    """Test suppression article"""
    products = ProductsPage(driver)
    products.add_product_to_cart(0)
    products.go_to_cart()
    
    cart = CartPage(driver)
    assert cart.remove_item_from_cart(0), "Impossible de supprimer l'article"
    assert cart.get_cart_items_count() == 0, "Le panier devrait être vide"

def test_continue_shopping(driver):
    """Test retour aux produits"""
    products = ProductsPage(driver)
    products.go_to_cart()
    
    cart = CartPage(driver)
    assert cart.continue_shopping(), "Continue shopping échoué"



