import pytest
from selenium import webdriver
from pages.login_page import LoginPage

# -----------------------------
# Ajouter l'option --browser
# -----------------------------
def pytest_addoption(parser):
    parser.addoption("--browser", action="store", default="chrome")


# -----------------------------
# Fixture driver
# -----------------------------
@pytest.fixture
def driver(request):
    browser_name = request.config.getoption("--browser").lower()
    if browser_name == "chrome":
        driver = webdriver.Chrome()
    elif browser_name == "edge":
        driver = webdriver.Edge()
    else:
        raise ValueError(f"Navigateur inconnu: {browser_name}")

    driver.maximize_window()
    driver.get("https://www.saucedemo.com/")
    yield driver
    driver.quit()

# -----------------------------
# Tests
# -----------------------------
def test_login_page_elements_visible(driver):
    """Test que tous les éléments de login sont visibles"""
    login = LoginPage(driver)
    assert login.is_login_page_displayed(), "Les éléments login ne sont pas visibles"

def test_login_success_standard_user(driver):
    """Test connexion standard_user"""
    login = LoginPage(driver)
    login.standard_login()
    assert login.is_login_successful(), "La connexion standard_user a échoué"

def test_login_locked_out_user(driver):
    """Test utilisateur bloqué"""
    login = LoginPage(driver)
    login.login_with_user("locked_out_user")
    error_message = login.get_error_message()
    assert "locked" in error_message.lower(), "Message d'erreur manquant"

def test_login_invalid_credentials(driver):
    """Test identifiants invalides"""
    login = LoginPage(driver)
    login.login("invalid_user", "wrong_pass")
    assert login.get_error_message() != "", "Message d'erreur manquant"

def test_login_empty_fields(driver):
    """Test champs vides"""
    login = LoginPage(driver)
    login.login("", "")
    error_message = login.get_error_message()
    assert error_message != "", "Message d'erreur manquant pour champs vides"


