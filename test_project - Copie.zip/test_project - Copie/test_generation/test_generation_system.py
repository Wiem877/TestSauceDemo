"""
Script de test pour le système de génération de tests IA
"""
import os
import sys

# Ajouter le dossier utils au path
sys.path.append(os.path.join(os.path.dirname(__file__), 'utils'))

def test_system():
    print("🧪 TEST DU SYSTÈME DE GÉNÉRATION DE TESTS")
    print("=" * 50)
    
    # Test 1: Vérifier les dépendances
    print("1. Vérification des dépendances...")
    try:
        import yaml
        import openai
        from jinja2 import Template
        print("   ✅ Toutes les dépendances sont disponibles")
    except ImportError as e:
        print(f"   ❌ Dépendance manquante: {e}")
        return False
    
    # Test 2: Vérifier l'analyzer de Page Objects
    print("2. Test de l'analyzer de Page Objects...")
    try:
        from test_generation.page_object_analyzer import PageObjectAnalyzer
        analyzer = PageObjectAnalyzer()
        summary = analyzer.generate_methods_summary()
        if "AUCUNE MÉTHODE TROUVÉE" in summary:
            print("   ⚠️  Aucun Page Object trouvé (normal si vous n'avez pas encore créé de tests)")
        else:
            print("   ✅ Page Objects analysés avec succès")
        print(f"   📊 Résumé: {len(summary.splitlines())} lignes générées")
    except Exception as e:
        print(f"   ❌ Erreur avec l'analyzer: {e}")
        return False
    
    # Test 3: Vérifier le fichier YAML
    print("3. Vérification du fichier YAML...")
    yaml_path = "test_generation/input/user_story_login.yaml"
    try:
        with open(yaml_path, 'r', encoding='utf-8') as f:
            content = f.read()
        import yaml
        data = yaml.safe_load(content)
        print(f"   ✅ YAML chargé: {data['user_story']['title']}")
        print(f"   📋 Critères: {len(data['acceptance_criteria'])}")
    except Exception as e:
        print(f"   ❌ Erreur avec le YAML: {e}")
        return False
    
    # Test 4: Vérifier le template
    print("4. Vérification du template...")
    template_path = "test_generation/templates/pytest_template.j2"
    try:
        with open(template_path, 'r', encoding='utf-8') as f:
            template_content = f.read()
        from jinja2 import Template
        template = Template(template_content)
        print("   ✅ Template chargé avec succès")
    except Exception as e:
        print(f"   ❌ Erreur avec le template: {e}")
        return False
    
    print("=" * 50)
    print("🎉 TOUS LES TESTS SYSTÈME SONT PASSÉS !")
    print("\n📝 Prochaine étape: Génération réelle des tests avec l'IA")
    print("   Vous aurez besoin de votre clé API OpenAI")
    return True

if __name__ == "__main__":
    test_system()