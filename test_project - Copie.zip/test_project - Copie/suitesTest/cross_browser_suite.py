# suitesTest/cross_browser_suite.py

import pytest
import os

def run_cross_browser_tests():
    """
    Lance les tests cross-browser présents dans suitesTest/
    """
    test_dir = os.path.dirname(os.path.abspath(__file__))

    pytest.main([
        test_dir,               # exécuter tout dans suitesTest/
        "--browser=all",        # ton plugin cross-browser
        "--disable-warnings",
        "-q"
    ])

if __name__ == "__main__":
    run_cross_browser_tests()
