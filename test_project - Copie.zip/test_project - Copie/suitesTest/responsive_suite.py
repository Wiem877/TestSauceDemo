import os
import pytest
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Définir les résolutions à tester (largeur x hauteur)
RESOLUTIONS = [
    (1920, 1080),  # Desktop Full HD
    (1366, 768),   # Laptop standard
    (1024, 768),   # Petit laptop / tablette paysage
    (768, 1024),   # Tablette portrait
    (375, 667),    # Mobile portrait
    (414, 896)     # Mobile grand écran
]

# Dossier pour les captures d'écran
SCREENSHOTS_DIR = os.path.join(os.getcwd(), "screenshots")
os.makedirs(SCREENSHOTS_DIR, exist_ok=True)

@pytest.mark.parametrize("width,height", RESOLUTIONS)
def test_responsive_login_elements(driver, width, height):
    """
    Teste la visibilité des éléments essentiels du login
    sur différentes résolutions et fait une capture d'écran.
    """
    # Redimensionner la fenêtre
    driver.set_window_size(width, height)
    driver.get("https://www.saucedemo.com/")

    # Vérifier le titre
    assert "Swag Labs" in driver.title, f"Title not correct at {width}x{height}"

    # Vérifier la présence des champs
    username_field = WebDriverWait(driver, 10).until(
        EC.visibility_of_element_located((By.ID, "user-name"))
    )
    password_field = WebDriverWait(driver, 10).until(
        EC.visibility_of_element_located((By.ID, "password"))
    )
    login_button = WebDriverWait(driver, 10).until(
        EC.visibility_of_element_located((By.ID, "login-button"))
    )

    # Assertions pour vérifier que les éléments sont visibles
    assert username_field.is_displayed(), f"Username field not visible at {width}x{height}"
    assert password_field.is_displayed(), f"Password field not visible at {width}x{height}"
    assert login_button.is_displayed(), f"Login button not visible at {width}x{height}"

    # Capturer la page
    screenshot_file = os.path.join(SCREENSHOTS_DIR, f"login_{width}x{height}.png")
    driver.save_screenshot(screenshot_file)
    print(f"📸 Screenshot saved: {screenshot_file}")
