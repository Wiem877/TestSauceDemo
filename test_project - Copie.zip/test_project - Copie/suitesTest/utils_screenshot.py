# suitesTest/utils_screenshot.py
import os
from datetime import datetime

def take_screenshot(driver, test_name):
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    browser = driver.capabilities["browserName"]
    
    screenshot_dir = os.path.join("..", "cross_browser", "results", "screenshots")
    os.makedirs(screenshot_dir, exist_ok=True)

    filename = f"{test_name}_{browser}_{timestamp}.png"
    path = os.path.join(screenshot_dir, filename)

    driver.save_screenshot(path)
    return path
