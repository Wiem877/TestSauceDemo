# suitesTest/performance_suite.py
from performance.k6_generator import K6ScriptGenerator
from performance.run_tests import K6TestRunner

class PerformanceTestSuite:
    """Suite de tests de performance étendue avec k6"""
    
    def __init__(self, gemini_api_key=None):
        self.generator = K6ScriptGenerator(api_key=gemini_api_key)
        self.runner = K6TestRunner()
    
    def generate_and_run_performance_tests(self):
        """Génère et exécute tous les tests de performance"""
        print("🎯 Génération et exécution des tests de performance...")
        
        # 1. Génération des scripts avec AI
        self.generator.generate_all_scripts()
        
        # 2. Exécution des tests
        success = self.runner.run_performance_suite()
        
        return success
    
    def run_specific_test(self, test_name):
        """Exécute un test de performance spécifique"""
        scripts = {
            'login': 'login_load.js',
            'full_flow': 'full_flow.js', 
            'stress': 'stress_test.js'
        }
        
        if test_name in scripts:
            return self.runner.run_test(scripts[test_name])
        else:
            print(f"❌ Test inconnu: {test_name}")
            return False