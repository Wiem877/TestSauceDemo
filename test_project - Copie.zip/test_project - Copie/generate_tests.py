from test_generation.gemini_test_generator import GeminiTestGenerator
import os
import jinja2

def main():
    print("🚀 LANCEMENT DE LA GÉNÉRATION DES TESTS...")
    
    if not os.path.exists("api_key.txt"):
        print("❌ api_key.txt non trouvé")
        return
    
    try:
        generator = GeminiTestGenerator()
        print("✅ Générateur initialisé")
        
        # Mapping explicite pour garantir 4 fichiers
        user_stories_mapping = [
            {"path": "test_generation/input/user_story_login.yaml", "page_type": "login"},
            {"path": "test_generation/input/user_story_product.yaml", "page_type": "products"}, 
            {"path": "test_generation/input/user_story_cart.yaml", "page_type": "cart"},
            {"path": "test_generation/input/user_story_checkout.yaml", "page_type": "checkout"}
        ]
        
        for story_mapping in user_stories_mapping:
            user_story_path = story_mapping["path"]
            page_type = story_mapping["page_type"]  # On utilise le mapping explicite
            
            if not os.path.exists(user_story_path):
                print(f"⚠️  Fichier non trouvé: {user_story_path}")
                continue
                
            print(f"\n📖 Traitement de: {user_story_path}")
            
            user_story = generator.load_user_story(user_story_path)
            if not user_story:
                continue
            
            # Générer le test avec le template
            generated_test = generate_test_with_template(user_story, page_type)
            
            if generated_test:
                # Créer le nom de fichier spécifique
                output_file = f"test_generation/output/test_{page_type}.py"
                
                os.makedirs("tests", exist_ok=True)
                with open(output_file, 'w', encoding='utf-8') as f:
                    f.write(generated_test)
                print(f"💾 Test sauvegardé: {output_file}")
            else:
                print(f"❌ Échec de la génération pour {user_story_path}")
        
        print("\n🎉 Génération terminée! 4 fichiers créés:")
        print("   ✅ test_generation/output/test_login.py")
        print("   ✅ test_generation/output/test_products.py") 
        print("   ✅ test_generation/output/test_cart.py")
        print("   ✅ test_generation/output/test_checkout.py")
        
    except Exception as e:
        print(f"❌ Erreur: {e}")
        import traceback
        traceback.print_exc()

def generate_test_with_template(user_story, page_type):
    """Génère le code de test en utilisant le template Jinja2"""
    try:
        # Configuration du loader de templates
        template_loader = jinja2.FileSystemLoader(searchpath="test_generation/templates/")
        template_env = jinja2.Environment(loader=template_loader)
        
        # Charger le template - CHEMIN CORRECT
        template_file = "pytest_template.j2"
        template = template_env.get_template(template_file)
        
        # Préparer les données pour le template
        template_data = {
            'user_story': user_story,
            'page_type': page_type  # On passe seulement le page_type
        }
        
        # Rendre le template
        generated_code = template.render(template_data)
        
        # Valider que le code généré n'est pas vide
        if generated_code and len(generated_code.strip()) > 0:
            return generated_code
        else:
            print("❌ Le template a généré un code vide")
            return None
            
    except jinja2.TemplateNotFound:
        print(f"❌ Template non trouvé: test_generation/templates/{template_file}")
        return None
    except Exception as e:
        print(f"❌ Erreur lors de la génération du template: {e}")
        import traceback
        traceback.print_exc()
        return None

if __name__ == "__main__":
    main()