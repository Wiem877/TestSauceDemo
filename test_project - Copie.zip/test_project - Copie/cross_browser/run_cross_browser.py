import os
import subprocess
import sys
import json
from datetime import datetime
import webbrowser
import time

# ================================
# CONFIGURATION
# ================================
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))

# Chemin corrigé vers le fichier de test
TEST_FILE = os.path.join(PROJECT_ROOT, "..", "test_generation", "output", "test_login.py")

RESULT_FOLDER = os.path.join(PROJECT_ROOT, "results")
os.makedirs(RESULT_FOLDER, exist_ok=True)

# Navigateurs à tester
BROWSERS = ["chrome", "edge"]

# Chemins des navigateurs
CHROME_PATH = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
EDGE_PATH = r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"

# ================================
# FONCTION: EXECUTER LES TESTS
# ================================
def execute_tests(browser_name):
    """Exécute les tests pour un navigateur spécifique et retourne un dictionnaire de résultats"""

    if not os.path.exists(TEST_FILE):
        print(f"❌ Fichier de test introuvable: {TEST_FILE}")
        return {
            "browser": browser_name,
            "log_file": None,
            "html_file": None,
            "json_file": None,
            "passed": 0,
            "failed": 0,
            "skipped": 0,
            "total": 0,
            "execution_time": 0,
            "return_code": 1,
            "json_data": {}
        }

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    log_file = os.path.join(RESULT_FOLDER, f"test_{browser_name}_{timestamp}.log")
    json_file = os.path.join(RESULT_FOLDER, f"results_{browser_name}_{timestamp}.json")
    html_file = os.path.join(RESULT_FOLDER, f"report_{browser_name}_{timestamp}.html")

    print(f"\n{'='*70}")
    print(f"🚀 LANCEMENT DES TESTS SUR {browser_name.upper()}")
    print(f"{'='*70}")
    print(f"📁 Fichier de test: {TEST_FILE}")
    print(f"📄 Log: {log_file}")
    print(f"📊 Rapport: {html_file}")

    cmd = [
        sys.executable, "-m", "pytest",
        TEST_FILE,
        f"--browser={browser_name}",
        f"--html={html_file}",
        "--self-contained-html",
        "--json-report",
        f"--json-report-file={json_file}",
        "-v",
        "--tb=short",
        "--color=yes"
    ]

    start_time = time.time()
    with open(log_file, "w", encoding="utf-8") as log:
        log.write(f"Commande exécutée: {' '.join(cmd)}\n")
        log.write(f"Début: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        log.write("=" * 80 + "\n\n")

        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding='utf-8',
            bufsize=1,
            universal_newlines=True
        )

        output_lines = []
        for line in process.stdout:
            print(line, end='')
            log.write(line)
            output_lines.append(line)

        return_code = process.wait()
        execution_time = time.time() - start_time

    # Lecture JSON pour les stats
    passed = failed = skipped = total = 0
    json_data = {}
    if os.path.exists(json_file):
        try:
            with open(json_file, 'r', encoding='utf-8') as f:
                json_data = json.load(f)
            for t in json_data.get("tests", []):
                outcome = t.get("outcome")
                if outcome == "passed":
                    passed += 1
                elif outcome == "failed":
                    failed += 1
                elif outcome == "skipped":
                    skipped += 1
            total = passed + failed + skipped
        except Exception as e:
            print(f"⚠️ Erreur lecture JSON: {e}")

    print(f"\n{'='*70}")
    print(f"📊 RÉSUMÉ {browser_name.upper()}")
    print(f"{'='*70}")
    print(f"✅ PASSED: {passed}")
    print(f"❌ FAILED: {failed}")
    print(f"⏭️  SKIPPED: {skipped}")
    print(f"📈 TOTAL: {total}")
    print(f"⏱️  Temps d'exécution: {execution_time:.2f} secondes")
    print(f"🔚 Code de sortie: {return_code}")

    return {
        "browser": browser_name,
        "log_file": log_file,
        "html_file": html_file,
        "json_file": json_file if os.path.exists(json_file) else None,
        "passed": passed,
        "failed": failed,
        "skipped": skipped,
        "total": total,
        "execution_time": execution_time,
        "return_code": return_code,
        "json_data": json_data
    }

# ================================
# GENERATION RAPPORT CONSOLIDÉ
# ================================
def generate_consolidated_report(results):
    """Génère un rapport HTML consolidé pour tous les navigateurs avec interface améliorée"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_path = os.path.join(RESULT_FOLDER, f"Rapport_Cross_Browser_{timestamp}.html")

    total_tests = sum(r["total"] for r in results)
    total_passed = sum(r["passed"] for r in results)
    total_failed = sum(r["failed"] for r in results)
    total_skipped = sum(r["skipped"] for r in results)
    total_time = sum(r["execution_time"] for r in results)
    success_rate = (total_passed / total_tests * 100) if total_tests > 0 else 0

    # Lignes du tableau par navigateur
    browser_rows = ""
    for r in results:
        status = "✅ PASS" if r["failed"] == 0 else "❌ FAIL"
        status_class = "success" if r["failed"] == 0 else "danger"
        browser_rows += f"""
        <tr>
            <td>{r['browser'].upper()}</td>
            <td><span class="badge bg-{status_class}">{status}</span></td>
            <td>{r['total']}</td>
            <td class="text-success">{r['passed']}</td>
            <td class="text-danger">{r['failed']}</td>
            <td class="text-warning">{r['skipped']}</td>
            <td>{r['execution_time']:.2f}s</td>
            <td>
                {'<a href="'+r['log_file']+'" class="btn btn-sm btn-outline-primary" target="_blank">Log</a>' if r['log_file'] else ''}
                {'<a href="'+r['html_file']+'" class="btn btn-sm btn-outline-success" target="_blank">Report</a>' if r['html_file'] else ''}
            </td>
        </tr>
        """

    html = f"""
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Rapport Cross-Browser</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body {{
    background: #f5f7fa;
    font-family: 'Segoe UI', sans-serif;
}}
.header {{
    background: linear-gradient(135deg,#2c3e50,#3498db);
    color: white;
    padding: 2rem;
    border-radius: 0 0 20px 20px;
    text-align: center;
}}
.stat-card {{
    background: white;
    border-radius: 15px;
    padding: 1.5rem;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    text-align: center;
}}
.stat-number {{
    font-size: 2rem;
    font-weight: bold;
}}
.table-container {{
    margin-top: 2rem;
    background: white;
    padding: 1rem;
    border-radius: 15px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}}
.footer {{
    background: #2c3e50;
    color: white;
    padding: 1rem;
    text-align: center;
    margin-top: 2rem;
    border-radius: 15px 15px 0 0;
}}
</style>
</head>
<body>
<div class="header">
    <h1>Rapport Cross-Browser Testing</h1>
    <p>Fichier testé: {os.path.basename(TEST_FILE)}</p>
    <p>Date: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}</p>
    <h2>Taux de réussite global: {success_rate:.1f}%</h2>
</div>

<div class="container">
    <div class="row g-4 text-center mt-4">
        <div class="col-md-3">
            <div class="stat-card">
                <div>Total Navigateurs</div>
                <div class="stat-number">{len(results)}</div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stat-card">
                <div>Total Tests</div>
                <div class="stat-number">{total_tests}</div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stat-card">
                <div>Tests Passés</div>
                <div class="stat-number text-success">{total_passed}</div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stat-card">
                <div>Tests Échoués</div>
                <div class="stat-number text-danger">{total_failed}</div>
            </div>
        </div>
    </div>

    <div class="table-container">
        <h3>Détail par Navigateur</h3>
        <div class="table-responsive">
            <table class="table table-hover table-bordered">
                <thead>
                    <tr>
                        <th>Navigateur</th>
                        <th>Status</th>
                        <th>Total</th>
                        <th>Passés</th>
                        <th>Échoués</th>
                        <th>Ignorés</th>
                        <th>Temps</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {browser_rows}
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="footer">
    Généré automatiquement par Cross-Browser Testing Suite &copy; {datetime.now().strftime('%Y')}
</div>
</body>
</html>
"""
    with open(report_path, "w", encoding="utf-8") as f:
        f.write(html)

    return report_path, success_rate

# ================================
# MAIN
# ================================
def main():
    print("\n🚀 CROSS-BROWSER TESTING SUITE")
    print(f"Fichier de test: {TEST_FILE}")
    print(f"Navigateurs: {', '.join(BROWSERS)}")
    print(f"Dossier résultats: {RESULT_FOLDER}")
    print(f"Python: {sys.version.split()[0]}")

    all_results = []
    for browser in BROWSERS:
        result = execute_tests(browser)
        all_results.append(result)
        if browser != BROWSERS[-1]:
            time.sleep(2)

    report_path, success_rate = generate_consolidated_report(all_results)

    # Ouvrir dans Chrome si disponible
    if os.path.exists(CHROME_PATH):
        webbrowser.register('chrome', None, webbrowser.BackgroundBrowser(CHROME_PATH))
        webbrowser.get('chrome').open(f"file:///{report_path}")
    else:
        webbrowser.open(f"file:///{report_path}")

    total_failed = sum(r["failed"] for r in all_results)
    return 0 if total_failed == 0 else 1

# ================================
# POINT D'ENTRÉE
# ================================
if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\n❌ Exécution interrompue par l'utilisateur")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ ERREUR: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
