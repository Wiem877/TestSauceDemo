# cross_browser/diagnostic.py
"""
Diagnostic de l'erreur d'exécution
"""

import subprocess
import sys
import os

# Test direct pour voir l'erreur
cmd = [
    sys.executable, "-m", "pytest",
    "test_generation/output/test_login.py",
    "--browser=chrome",
    "-v",
    "--tb=long"  # Afficher toute la trace
]

print("🔍 Diagnostic de l'erreur...")
print(f"Commande: {' '.join(cmd)}")
print("-" * 80)

result = subprocess.run(
    cmd,
    capture_output=True,
    text=True,
    shell=True
)

print("STDOUT:")
print(result.stdout)
print("\n" + "=" * 80)
print("STDERR:")
print(result.stderr)