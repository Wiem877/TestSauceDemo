from selenium.webdriver.common.by import By
from .base_page import BasePage  # ✅ Import depuis base_page

class LoginPage(BasePage):  # ✅ Hérite de BasePage
    """
    Page Object Model pour la page de login de SauceDemo
    Centralise tous les éléments et actions de la page de connexion
    """
    
    def __init__(self, driver):
        super().__init__(driver)  # ✅ Appel correct du constructeur parent
    
    # ✅ LOCATORS - Définition de tous les éléments de la page
    USERNAME_FIELD = (By.ID, "user-name")  # Champ de saisie du nom d'utilisateur
    PASSWORD_FIELD = (By.ID, "password")    # Champ de saisie du mot de passe
    LOGIN_BUTTON = (By.ID, "login-button")  # Bouton de connexion
    ERROR_MESSAGE = (By.CSS_SELECTOR, "[data-test='error']")  # Message d'erreur
    LOGO = (By.CLASS_NAME, "login_logo")    # Logo de l'application
    
    # 🗂️ DICTIONNAIRE DE TOUS LES UTILISATEURS VALIDES
    VALID_USERS = {
        "standard_user": "secret_sauce",
        "locked_out_user": "secret_sauce", 
        "problem_user": "secret_sauce",
        "performance_glitch_user": "secret_sauce",
        "error_user": "secret_sauce",
        "visual_user": "secret_sauce"
    }
    
    def enter_username(self, username):
        """
        Saisit un nom d'utilisateur dans le champ correspondant
        Utilise les méthodes de BasePage
        """
        username_field = self.find_clickable_element(*self.USERNAME_FIELD)  # ✅ Méthode BasePage
        username_field.clear()  # Efface tout texte existant
        username_field.send_keys(username)  # Saisit le nom d'utilisateur
        return self  # Retourne l'instance pour le method chaining
    
    def enter_password(self, password):
        """
        Saisit un mot de passe dans le champ correspondant
        Utilise les méthodes de BasePage
        """
        password_field = self.find_clickable_element(*self.PASSWORD_FIELD)  # ✅ Méthode BasePage
        password_field.clear()  # Efface tout texte existant
        password_field.send_keys(password)  # Saisit le mot de passe
        return self  # Retourne l'instance pour le method chaining
    
    def click_login(self):
        """
        Clique sur le bouton de connexion
        Utilise les méthodes de BasePage
        """
        login_button = self.find_clickable_element(*self.LOGIN_BUTTON)  # ✅ Méthode BasePage
        login_button.click()  # Effectue le clic
        return self  # Retourne l'instance pour le method chaining
    
    def login(self, username, password):
        """
        Effectue une tentative de connexion complète
        """
        self.enter_username(username)  # Saisit le nom d'utilisateur
        self.enter_password(password)  # Saisit le mot de passe
        self.click_login()  # Clique sur connexion
        return self  # Retourne l'instance pour le method chaining
    
    def login_with_user(self, username="standard_user"):
        """
        Effectue une connexion avec n'importe quel utilisateur valide
        Par défaut utilise 'standard_user' pour rester compatible
        """
        # ✅ Vérification que l'utilisateur existe
        if username not in self.VALID_USERS:
            raise ValueError(f"Utilisateur non valide: {username}")
        
        # 🔑 Récupération du mot de passe
        password = self.VALID_USERS[username]
        
        # 🔄 Utilise la méthode login existante
        return self.login(username, password)
    
    def standard_login(self):
        """
        Effectue une connexion avec les identifiants valides par défaut
        Utilise 'standard_user' qui est le compte normal sans problèmes
        """
        return self.login_with_user("standard_user")  # Utilise la nouvelle méthode
    
    def get_error_message(self):
        """
        Récupère le texte du message d'erreur s'il est affiché
        Utilise les méthodes de BasePage
        """
        try:
            error_element = self.find_element(*self.ERROR_MESSAGE)  # ✅ Méthode BasePage
            return error_element.text  # Retourne le texte de l'erreur
        except:
            return ""  # Retourne une chaîne vide si pas d'erreur
    
    def is_login_successful(self):
        """
        Vérifie si la connexion a réussi en contrôlant l'URL
        Utilise les méthodes de BasePage
        """
        return "inventory" in self.get_current_url()  # ✅ Méthode BasePage
    
    def is_login_page_displayed(self):
        """
        Vérifie si la page de login est correctement affichée
        Utilise les méthodes de BasePage
        """
        return all([
            self.is_element_visible(*self.USERNAME_FIELD),  # ✅ Méthode BasePage
            self.is_element_visible(*self.PASSWORD_FIELD),  # ✅ Méthode BasePage
            self.is_element_visible(*self.LOGIN_BUTTON)     # ✅ Méthode BasePage
        ])