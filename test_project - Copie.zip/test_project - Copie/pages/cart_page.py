from selenium.webdriver.common.by import By
from .base_page import BasePage

class CartPage(BasePage):
    """
    Page Object Model pour la page du panier SauceDemo
    """
    
    def __init__(self, driver):
        super().__init__(driver)
    
    # Locators
    CART_TITLE = (By.CLASS_NAME, "title")
    CART_ITEMS = (By.CLASS_NAME, "cart_item")
    REMOVE_BUTTONS = (By.CLASS_NAME, "cart_button")
    CONTINUE_SHOPPING_BTN = (By.ID, "continue-shopping")
    CHECKOUT_BTN = (By.ID, "checkout")
    CART_QUANTITY = (By.CLASS_NAME, "cart_quantity")
    ITEM_PRICE = (By.CLASS_NAME, "inventory_item_price")
    
    def is_cart_page_displayed(self):
        """Vérifie si la page panier est affichée"""
        return self.is_element_visible(*self.CART_TITLE)
    
    def get_cart_items_count(self):
        """Retourne le nombre d'articles dans le panier"""
        try:
            items = self.driver.find_elements(*self.CART_ITEMS)
            return len(items)
        except:
            return 0
    
    def remove_item_from_cart(self, index=0):
        """Supprime un article du panier"""
        try:
            remove_buttons = self.driver.find_elements(*self.REMOVE_BUTTONS)
            if remove_buttons and index < len(remove_buttons):
                remove_buttons[index].click()
                return True
        except:
            pass
        return False
    
    def continue_shopping(self):
        """Retourne à la page produits"""
        try:
            self.find_clickable_element(*self.CONTINUE_SHOPPING_BTN).click()
            return True
        except:
            return False
    
    def proceed_to_checkout(self):
        """Poursuit vers le checkout"""
        try:
            self.find_clickable_element(*self.CHECKOUT_BTN).click()
            return True
        except:
            return False
    
    def get_item_details(self, index=0):
        """Récupère les détails d'un article du panier"""
        try:
            items = self.driver.find_elements(*self.CART_ITEMS)
            if items and index < len(items):
                item = items[index]
                name = item.find_element(By.CLASS_NAME, "inventory_item_name").text
                price = item.find_element(By.CLASS_NAME, "inventory_item_price").text
                quantity = item.find_element(By.CLASS_NAME, "cart_quantity").text
                return {
                    'name': name,
                    'price': price,
                    'quantity': quantity
                }
        except:
            pass
        return None