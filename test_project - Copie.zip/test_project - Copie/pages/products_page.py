from selenium.webdriver.common.by import By
from .base_page import BasePage  # ✅ Import depuis base_page
import random  # ✅ Ajout de l'import random manquant

class ProductsPage(BasePage):  # ✅ Hérite de BasePage
    """
    Page Object Model pour la page des produits de SauceDemo
    """
    
    def __init__(self, driver):
        super().__init__(driver)  # ✅ Appel du constructeur parent
    
    # ✅ LOCATORS
    PRODUCTS_TITLE = (By.CLASS_NAME, "title")
    INVENTORY_LIST = (By.CLASS_NAME, "inventory_list")
    SHOPPING_CART = (By.CLASS_NAME, "shopping_cart_link")
    MENU_BUTTON = (By.ID, "react-burger-menu-btn")
    LOGOUT_LINK = (By.ID, "logout_sidebar_link")
    CART_BADGE = (By.CLASS_NAME, "shopping_cart_badge")
    ADD_TO_CART_BUTTONS = (By.CLASS_NAME, "btn_inventory")
    INVENTORY_ITEMS = (By.CLASS_NAME, "inventory_item")
    
    def is_products_page_displayed(self):
        """Vérifie si la page produits est affichée"""
        return self.is_element_visible(*self.PRODUCTS_TITLE)  # ✅ Méthode BasePage
    
    def get_product_count(self):
        """Retourne le nombre de produits affichés"""
        try:
            products = self.driver.find_elements(*self.INVENTORY_ITEMS)
            return len(products)
        except:
            return 0
    
    def add_product_to_cart(self, product_selector=0):
        """
        ✅ MÉTHODE UNIVERSELLE : Ajoute un produit au panier
        Accepte différents types de sélecteurs :
        - int (index) : 0, 1, 2... 
        - str (nom) : "Sauce Labs Backpack"
        - "random" : produit aléatoire
        - "first" : premier produit (défaut)
        """
        try:
            # 🔍 ÉTAPE 1 : Trouver TOUS les boutons "Add to Cart" sur la page
            add_buttons = self.driver.find_elements(*self.ADD_TO_CART_BUTTONS)  # liste de tous les boutons comme 
            
            # ❌ Vérifier si au moins un bouton existe
            if not add_buttons:
                return False  # Aucun produit disponible
            
            # 🎯 ÉTAPE 2 : DÉTERMINER LE TYPE DE SÉLECTEUR ET AGIR EN CONSÉQUENCE
            
            # 📌 CAS 1 : Sélecteur est un INDEX NUMÉRIQUE (0, 1, 2...)
            if isinstance(product_selector, int):
                # isinstance() vérifie si product_selector est un nombre entier
                # Exemple: product_selector = 2 (troisième produit)
                
                # Vérifier que l'index est dans les limites de la liste
                if 0 <= product_selector < len(add_buttons):
                    # Si index valide, cliquer sur le bouton correspondant
                    add_buttons[product_selector].click()
                    # Exemple: add_buttons[2].click() → clique sur le 3ème bouton
                    return True  # ✅ Succès
            
            # 📌 CAS 2 : Sélecteur est un NOM DE PRODUIT (string qui n'est pas "random" ou "first")
            elif isinstance(product_selector, str) and product_selector not in ["random", "first"]:
                # Exemple: product_selector = "Sauce Labs Backpack"
                
                # Trouver tous les éléments produits sur la page
                products = self.driver.find_elements(*self.INVENTORY_ITEMS)
                # products = [produit1, produit2, produit3...]
                
                # Parcourir chaque produit pour trouver celui qui correspond au nom
                for i, product in enumerate(products):
                    # enumerate() donne à la fois l'index (i) et l'élément (product)
                    # i = 0, product = premier élément produit
                    # i = 1, product = deuxième élément produit, etc.
                    
                    # Trouver l'élément qui contient le nom du produit dans ce produit spécifique
                    name_element = product.find_element(By.CLASS_NAME, "inventory_item_name")
                    # name_element = élément HTML qui contient le texte du nom
                    
                    # Vérifier si le nom recherché est dans le nom du produit (insensible à la casse)
                    if product_selector.lower() in name_element.text.lower():
                        # Si nom trouvé, vérifier que l'index correspond à un bouton existant
                        if i < len(add_buttons):
                            # Cliquer sur le bouton "Add to Cart" qui correspond à ce produit
                            add_buttons[i].click()
                            # Exemple: si produit trouvé à l'index 3, cliquer sur add_buttons[3]
                            return True  # ✅ Succès
            
            # 📌 CAS 3 : Sélecteur est "random" → PRODUIT ALÉATOIRE
            elif product_selector == "random":
                # Générer un index aléatoire entre 0 et (nombre_de_boutons - 1)
                random_index = random.randint(0, len(add_buttons) - 1)
                # Exemple: si 6 boutons → random_index entre 0 et 5
                
                # Cliquer sur le bouton à l'index aléatoire
                add_buttons[random_index].click()
                return True  # ✅ Succès
            
            # 📌 CAS 4 : Sélecteur est "first" ou AUTRE VALEUR → PREMIER PRODUIT (défaut)
            else:  
                # "first" ou toute autre valeur non reconnue → prendre le premier produit
                add_buttons[0].click()  # Toujours le premier bouton
                return True  # ✅ Succès
                
            # ❌ Si on arrive ici, aucun cas n'a fonctionné
            return False
            
        except Exception as e:
            # 🚨 Gestion des erreurs : si quelque chose plante pendant le processus
            print(f"❌ Erreur lors de l'ajout au panier: {e}")
            return False  # ❌ Échec
    
    def get_cart_badge_count(self):
        """Retourne le nombre d'articles dans le panier"""
        try:
            badge = self.find_element(*self.CART_BADGE)  # ✅ Méthode BasePage
            return badge.text
        except:
            return "0"
    
    def go_to_cart(self):
        """Clique sur le panier"""
        try:
            self.find_clickable_element(*self.SHOPPING_CART).click()  # ✅ Méthode BasePage
            return True
        except:
            return False
    
    def logout(self):
        """Déconnexion de l'application"""
        try:
            self.find_clickable_element(*self.MENU_BUTTON).click()  # ✅ Méthode BasePage
            self.find_clickable_element(*self.LOGOUT_LINK).click()  # ✅ Méthode BasePage
            self.wait_for_url_contains("login", timeout=10) #attendre le navigateur
            
            return True
        except:
            return False
    def get_page_title(self):
     #Retourne le texte visible du titre de la page
        return self.get_element_text(*self.PRODUCTS_TITLE)
    