from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

class BasePage:
    """
    Classe de base pour toutes les pages
    Centralise toutes les méthodes communes
    """
    
    def __init__(self, driver):
        self.driver = driver
        self.wait = WebDriverWait(driver, 10)
    
    def find_element(self, by, value):
        """Trouve un élément avec attente explicite"""
        return self.wait.until(EC.presence_of_element_located((by, value)))
    
    def find_clickable_element(self, by, value):
        """Trouve un élément cliquable"""
        return self.wait.until(EC.element_to_be_clickable((by, value)))
    
    def is_element_visible(self, by, value):
        """Vérifie si un élément est visible"""
        try:
            return self.find_element(by, value).is_displayed()
        except:
            return False
    
    def get_page_title(self):
        """Retourne le titre de la page"""
        return self.driver.title
    
    def get_current_url(self):
        """Retourne l'URL actuelle"""
        return self.driver.current_url
    
    def wait_for_url_contains(self, text, timeout=10):
        """Attend que l'URL contienne un texte spécifique"""
        return WebDriverWait(self.driver, timeout).until(
            EC.url_contains(text)
        )
    
    def take_screenshot(self, filename):
        """Prend une capture d'écran"""
        self.driver.save_screenshot(filename)
    def get_element_text(self, by, locator, timeout=10):
        """Retourne le texte visible d'un élément après l'avoir attendu"""
        element = WebDriverWait(self.driver, timeout).until(
            EC.visibility_of_element_located((by, locator))
        )
        return element.text    
    # BasePage.py
    def type_text(self, by, locator, text, timeout=10):

        element = WebDriverWait(self.driver, timeout).until(
        EC.visibility_of_element_located((by, locator))
        )
        element.clear()
        element.send_keys(text)
