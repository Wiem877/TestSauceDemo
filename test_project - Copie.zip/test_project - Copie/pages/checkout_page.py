from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, StaleElementReferenceException
from .base_page import BasePage

class CheckoutPage(BasePage):

    FIRST_NAME_FIELD = (By.ID, "first-name")
    LAST_NAME_FIELD = (By.ID, "last-name")
    POSTAL_CODE_FIELD = (By.ID, "postal-code")
    CONTINUE_BTN = (By.ID, "continue")
    FINISH_BTN = (By.ID, "finish")
    COMPLETE_HEADER = (By.CLASS_NAME, "complete-header")
    ERROR_MESSAGE = (By.CSS_SELECTOR, ".error-message-container")
    SUMMARY_CONTAINER = (By.CLASS_NAME, "cart_item")  # ← modifié

    def __init__(self, driver, wait_time=15):
        super().__init__(driver)
        self.wait = WebDriverWait(driver, wait_time, ignored_exceptions=[StaleElementReferenceException])
        self.wait.until(EC.visibility_of_element_located(self.FIRST_NAME_FIELD))

    def fill_checkout_info(self, first_name, last_name, postal_code):
        self.type_text(*self.FIRST_NAME_FIELD, first_name)
        self.type_text(*self.LAST_NAME_FIELD, last_name)
        self.type_text(*self.POSTAL_CODE_FIELD, postal_code)

    def continue_to_overview(self):
        continue_btn = self.wait.until(EC.element_to_be_clickable(self.CONTINUE_BTN))
        self.driver.execute_script("arguments[0].scrollIntoView(true);", continue_btn)
        continue_btn.click()

        # Attendre que tous les éléments du panier soient visibles
        self.wait.until(EC.visibility_of_all_elements_located(self.SUMMARY_CONTAINER))
        # Attendre que le bouton Finish soit cliquable
        finish_btn = self.wait.until(EC.element_to_be_clickable(self.FINISH_BTN))
        self.driver.execute_script("arguments[0].scrollIntoView(true);", finish_btn)

    def finish_checkout(self):
        finish_btn = self.wait.until(EC.element_to_be_clickable(self.FINISH_BTN))
        self.driver.execute_script("arguments[0].scrollIntoView(true);", finish_btn)
        finish_btn.click()
        self.wait.until(EC.visibility_of_element_located(self.COMPLETE_HEADER))

    def is_checkout_complete(self):
        try:
            header = self.wait.until(EC.visibility_of_element_located(self.COMPLETE_HEADER))
            return "Thank you" in header.text
        except TimeoutException:
            return False

    def get_error_message(self):
        try:
            container = self.wait.until(EC.visibility_of_element_located(self.ERROR_MESSAGE))
            return container.text.strip()
        except TimeoutException:
            return ""

    def click_continue_for_error(self):
        continue_btn = self.wait.until(EC.element_to_be_clickable(self.CONTINUE_BTN))
        self.driver.execute_script("arguments[0].scrollIntoView(true);", continue_btn)
        continue_btn.click()
