import pytest # Framework de test principal Création et exécution des tests
from selenium import webdriver  #Classe principale pour contrôler les navigateurs
from selenium.webdriver.chrome.service import Service as ChromeService #Gérer le driver exécutable de chaque navigateur
from selenium.webdriver.firefox.service import Service as FirefoxService
from selenium.webdriver.edge.service import Service as EdgeService
from webdriver_manager.chrome import ChromeDriverManager #Gestion automatique des drivers de navigateur
from webdriver_manager.firefox import GeckoDriverManager
from webdriver_manager.microsoft import EdgeChromiumDriverManager

#  Configuration centralisée
class Config:
    BASE_URL = "https://www.saucedemo.com/" #le site à tester
    DEFAULT_TIMEOUT = 10  
    HEADLESS = False  # navigateur visible

#  Fonction pour ajouter des options de ligne de commande
def pytest_addoption(parser):#choisir quel navigateur on va utiliser appelée AUTOMATIQUEMENT par pytest
    parser.addoption(
        "--browser", 
        action="store", 
        default="chrome", # ← Valeur PAR DÉFAUT
        help="Navigateur à utiliser: chrome, firefox, edge"
    )
    parser.addoption(
        "--resolution", 
        action="store", 
        default="1920x1080",
        help="Résolution de la fenêtre (ex: 1920x1080, 1366x768)"
    )

# 🚀 Fixture principale améliorée
@pytest.fixture(scope="function")
def driver(request):
    
    # 📥 Récupération des paramètres
    browser_name = request.config.getoption("--browser") #recupere le navigateur choisi
    headless_mode = Config.HEADLESS  # Récupère le mode headless depuis la configuration
    resolution = request.config.getoption("--resolution")
    driver = None # Initialisation de la variable driver
    
    # 🖥️ Configuration Chrome
    if browser_name == "chrome":
        chrome_options = webdriver.ChromeOptions()
        
        # 🔧 Options de performance et stabilité
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--disable-gpu")
        chrome_options.add_argument("--disable-extensions")
        chrome_options.add_argument(f"--window-size={resolution}")
        
        # 📦 Installation et initialisation
        service = ChromeService(ChromeDriverManager().install())
        driver = webdriver.Chrome(service=service, options=chrome_options)
    
    # 🦊 Configuration Firefox
    elif browser_name == "firefox":
        firefox_options = webdriver.FirefoxOptions()
        
        if headless_mode:
            firefox_options.add_argument("--headless")
        
        firefox_options.add_argument(f"--width={resolution.split('x')[0]}")
        firefox_options.add_argument(f"--height={resolution.split('x')[1]}")
        
        service = FirefoxService(GeckoDriverManager().install())
        driver = webdriver.Firefox(service=service, options=firefox_options)
    
    # 🌐 Configuration Edge
    elif browser_name == "edge":
        edge_options = webdriver.EdgeOptions()
    # HEADLESS
        if headless_mode:
            edge_options.add_argument("--headless=new")  # plus stable que --headless
    # OPTIONS
        edge_options.add_argument(f"--window-size={resolution}")
        edge_options.add_argument("--disable-gpu")
        edge_options.add_argument("--disable-dev-shm-usage")
        edge_options.add_argument("--disable-extensions")
        edge_options.add_argument("--no-sandbox")
        edge_options.add_argument("--remote-allow-origins=*")   # <= EXACTEMENT ICI
        edge_options.add_argument("--disable-blink-features=AutomationControlled")

    # EXPERIMENTAL OPTIONS
        edge_options.add_experimental_option("excludeSwitches", ["enable-automation"])
        edge_options.add_experimental_option("useAutomationExtension", False)

    # DRIVER
        service = EdgeService(EdgeChromiumDriverManager().install())
        driver = webdriver.Edge(service=service, options=edge_options)
        
    else:
        raise ValueError(f"Navigateur non supporté: {browser_name}")
    
    # ⚙️ Configuration commune à tous les navigateurs
    driver.implicitly_wait(Config.DEFAULT_TIMEOUT)  # ✅ 10s 
    driver.set_page_load_timeout(30)
    
    
    
    print(f"\n🎯 Navigateur: {browser_name}")
    print(f"🖥️  Mode: {'Headless' if headless_mode else 'Avec interface'}")
    print(f"📐 Résolution: {resolution}")
    
    # 🎲 Retour du driver aux tests
    yield driver
    
    # 🧹 Nettoyage après les tests
    print(f"\n🧹 Fermeture du navigateur {browser_name}")
    driver.quit()

# 🔄 Fixture pour les tests nécessitant une connexion
@pytest.fixture
def logged_in_driver(driver):
    """
    Fixture qui fournit un driver déjà connecté à l'application
    """
    from pages.login_page import LoginPage
    
    login_page = LoginPage(driver)
    login_page.standard_login()
    
    return driver

# 📊 Fixture pour les données de test
@pytest.fixture
def test_data():
    """
    Fixture pour fournir des données de test communes
    """
    return {
        "valid_user": "standard_user",
        "valid_password": "secret_sauce",
        "invalid_user": "invalid_user", 
        "invalid_password": "wrong_password",
        "locked_user": "locked_out_user"
    }